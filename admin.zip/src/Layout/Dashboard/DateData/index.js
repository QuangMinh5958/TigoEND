export { default } from "./DateData";
