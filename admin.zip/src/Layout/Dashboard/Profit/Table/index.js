export { default } from "./Table";
