export { default } from "./Legend";
